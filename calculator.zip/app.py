import sys

from PyQt6.QtCore import QSize, Qt
from PyQt6.QtGui import QAction
from PyQt6.QtWidgets import QApplication, QMainWindow, QTabWidget
from layouts import CombinationLayout, GridLayout
from utils.slots import squared, multiplicativeInverse, squareRoot
from utils.widgets import lineEdit

# Create a main class from PyQT for main app
class MainWindow(QMainWindow):
  def __init__(self):
    super().__init__()

    self.setWindowTitle("PyQt6 - Calculator")

    self.gridLineEdit = lineEdit()
    self.combinationLineEdit = lineEdit()

    # Set Tabs Widget
    self.tabs = QTabWidget()
    self.tabs.setTabPosition(QTabWidget.TabPosition.North)
    self.tabs.setMovable(True)

    # Add tab
    self.tabs.addTab(GridLayout(self.gridLineEdit).getLayout(), "Grid Layout")
    self.tabs.addTab(CombinationLayout(self.combinationLineEdit).getLayout(), "Combination Layout")

    self.setCentralWidget(self.tabs)

    # Set Menu
    self.menu = self.menuBar()

    # Squared Operation
    self.squaredButton = QAction("x²")
    self.squaredButton.setStatusTip("Squared operation")
    self.squaredButton.triggered.connect(lambda: squared(int(self.lineEdit.text()), lineEdit))
    
    # MultiplicativeInverse Operation
    self.multiplicativeInverseOperationButton = QAction("1/x")
    self.multiplicativeInverseOperationButton.setStatusTip("MultiplicativeInverse Operation")
    self.multiplicativeInverseOperationButton.triggered.connect(lambda: multiplicativeInverse(int(self.lineEdit.text()), lineEdit))
    
    # MultiplicativeInverse Operation
    self.squareRootButton = QAction("√x")
    self.squareRootButton.setStatusTip("MultiplicativeInverse Operation")
    self.squareRootButton.triggered.connect(lambda: squareRoot(int(self.lineEdit.text()), lineEdit))

    self.fileMenu = self.menu.addMenu("&Operasi Matematika")
    self.fileMenu.addAction(self.squaredButton)
    self.fileMenu.addSeparator()
    self.fileMenu.addAction(self.multiplicativeInverseOperationButton)
    self.fileMenu.addSeparator()
    self.fileMenu.addAction(self.squareRootButton)



# Create QApplication instance per application.
app = QApplication(sys.argv)

# Create an instance of MainWindow class
window = MainWindow()
window.show()

app.exec()
